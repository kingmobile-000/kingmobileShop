1) is folder ki files GitHub repo me daaliye: api/_keys.js, api/health.js, api/create-order.js, api/verify-payment.js, index.html
2) repo ke root wale purane create-order.js aur verify-payment.js DELETE kar dijiye (wo kaam nahi karte, sirf confuse karte hain)
3) Vercel > Settings > Environment Variables: RAZORPAY_KEY_ID aur RAZORPAY_KEY_SECRET -> teeno tick: Production, Preview, Development
4) Deployments > latest > Redeploy
5) check: https://kingmobilehusainganj1.vercel.app/api/health?deep=1  -> keysOk true aur razorpayAuth OK aana chahiye
